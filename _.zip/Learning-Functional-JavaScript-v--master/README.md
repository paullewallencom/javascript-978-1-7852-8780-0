## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/learning-functional-javascript-video/9781785287800)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Learning Functional JavaScript (v)	 [Video]
This is the code repository for Learning Functional JavaScript (v)
## About the Video Course
This video course is a comprehensive guide with live demonstrations of the constructs explained and practical results for thorough understanding.

<H2>What You Will Learn</H2>
<DIV class=book-info-will-learn-text>
<UL>
<LI>Explore higher-order functions, what they are and how to work with them
<LI>Solve issues related to asynchronous methods effectively by using promises
<LI>Use a library such as immutable.js to implement immutability
<LI>Implement immutability with Facebook’s React for super fast user interfaces
<LI>Work with scikit-learn to solve every problem in Machine Learning 
<LI>Combine a “functional core” to build a web application where most of the code is functional
<LI>Make efficient use of recursion with big data sets to make code easier to visualize</LI></UL></DIV>


## Related Products
* [Advanced Techniques for Exploring Data Sets with Pandas [Video]](https://www.packtpub.com/big-data-and-business-intelligence/advanced-techniques-exploring-data-sets-pandas-video?utm_source=github&utm_medium=repository&utm_campaign=9781788397599)

* [CISSP®️ Certification Domain 3: Security Architecture and Engineering Video Boot Camp 2019 [Video]](https://www.packtpub.com/application-development/cissp-certification-domain-3-security-architecture-and-engineering-video?utm_source=github&utm_medium=repository&utm_campaign=9781838646080)

* [CISSP®️ Certification Domain 3: Security Architecture and Engineering Video Boot Camp 2019 [Video]](https://www.packtpub.com/application-development/cissp-certification-domain-3-security-architecture-and-engineering-video?utm_source=github&utm_medium=repository&utm_campaign=9781838646080)

