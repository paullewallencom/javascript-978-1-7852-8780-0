var helloWorld = function helloWorld() {
  return "Hello, bleak world";
};

helloWorld.id = 42;

var person = {
  hello: function () {
    return "Hello";
  }
};

person.hello();
